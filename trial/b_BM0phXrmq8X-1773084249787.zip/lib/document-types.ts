export interface DocumentTemplate {
  id: string
  name: string
  category: "hr" | "operations" | "training" | "compliance"
  description: string
  icon: string
}

export interface GeneratedDocument {
  id: string
  templateId: string
  templateName: string
  createdBy: string
  createdByName: string
  createdAt: string
  status: "draft" | "submitted" | "approved" | "rejected"
  data: Record<string, string | number | boolean>
}

export const documentTemplates: DocumentTemplate[] = [
  {
    id: "resignation",
    name: "Resignation Application",
    category: "hr",
    description: "Submit a formal resignation request with notice period",
    icon: "FileText",
  },
  {
    id: "caution-letter",
    name: "Caution Letter",
    category: "hr",
    description: "Issue a warning letter to an employee for misconduct",
    icon: "AlertTriangle",
  },
  {
    id: "training-sheet",
    name: "Training Sheet",
    category: "training",
    description: "Record training completion and assessment results",
    icon: "GraduationCap",
  },
  {
    id: "leave-application",
    name: "Leave Application",
    category: "hr",
    description: "Request for annual, sick, or emergency leave",
    icon: "Calendar",
  },
  {
    id: "incident-report",
    name: "Incident Report",
    category: "operations",
    description: "Document security incidents and actions taken",
    icon: "FileWarning",
  },
  {
    id: "shift-handover",
    name: "Shift Handover Report",
    category: "operations",
    description: "Document shift handover details and pending tasks",
    icon: "ArrowRightLeft",
  },
  {
    id: "uniform-request",
    name: "Uniform Request Form",
    category: "hr",
    description: "Request new uniforms or equipment replacements",
    icon: "Shirt",
  },
  {
    id: "performance-review",
    name: "Performance Review",
    category: "hr",
    description: "Quarterly or annual performance evaluation form",
    icon: "Star",
  },
  {
    id: "overtime-request",
    name: "Overtime Request",
    category: "operations",
    description: "Request approval for overtime work hours",
    icon: "Clock",
  },
  {
    id: "visitor-log",
    name: "Visitor Log Sheet",
    category: "compliance",
    description: "Daily log of visitors at the security post",
    icon: "Users",
  },
]

export const sampleGeneratedDocuments: GeneratedDocument[] = [
  {
    id: "DOC001",
    templateId: "resignation",
    templateName: "Resignation Application",
    createdBy: "EMP003",
    createdByName: "Robert Chen",
    createdAt: "2026-03-08",
    status: "submitted",
    data: {
      lastWorkingDate: "2026-04-08",
      reason: "Personal reasons - relocating to another city",
      noticePeriod: "30 days",
    },
  },
  {
    id: "DOC002",
    templateId: "leave-application",
    templateName: "Leave Application",
    createdBy: "EMP002",
    createdByName: "Maria Santos",
    createdAt: "2026-03-09",
    status: "approved",
    data: {
      leaveType: "Annual Leave",
      startDate: "2026-03-15",
      endDate: "2026-03-18",
      reason: "Family vacation",
    },
  },
  {
    id: "DOC003",
    templateId: "incident-report",
    templateName: "Incident Report",
    createdBy: "EMP001",
    createdByName: "James Wilson",
    createdAt: "2026-03-10",
    status: "draft",
    data: {
      incidentDate: "2026-03-10",
      location: "Tech Corp HQ - Main Entrance",
      description: "Unauthorized vehicle attempted entry",
      actionTaken: "Denied entry, notified management",
    },
  },
  {
    id: "DOC004",
    templateId: "training-sheet",
    templateName: "Training Sheet",
    createdBy: "EMP001",
    createdByName: "James Wilson",
    createdAt: "2026-03-07",
    status: "approved",
    data: {
      traineeName: "David Martinez",
      trainingType: "Fire Safety Protocol",
      completionDate: "2026-03-07",
      score: 92,
      passed: true,
    },
  },
]
