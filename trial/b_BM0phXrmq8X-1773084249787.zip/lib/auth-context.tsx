"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type UserRole = "admin" | "supervisor" | "guard" | "officer"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  department: string
  employeeId: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Demo users for the system
const demoUsers: Record<string, { password: string; user: User }> = {
  "admin@secureguard.com": {
    password: "admin123",
    user: {
      id: "USR001",
      name: "Admin User",
      email: "admin@secureguard.com",
      role: "admin",
      department: "Administration",
      employeeId: "EMP000",
    },
  },
  "james.wilson@secureguard.com": {
    password: "james123",
    user: {
      id: "USR002",
      name: "James Wilson",
      email: "james.wilson@secureguard.com",
      role: "supervisor",
      department: "Operations",
      employeeId: "EMP001",
    },
  },
  "maria.santos@secureguard.com": {
    password: "maria123",
    user: {
      id: "USR003",
      name: "Maria Santos",
      email: "maria.santos@secureguard.com",
      role: "guard",
      department: "Field Operations",
      employeeId: "EMP002",
    },
  },
  "sarah.johnson@secureguard.com": {
    password: "sarah123",
    user: {
      id: "USR004",
      name: "Sarah Johnson",
      email: "sarah.johnson@secureguard.com",
      role: "officer",
      department: "Administration",
      employeeId: "EMP004",
    },
  },
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for stored session
    const storedUser = localStorage.getItem("secureguard_user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch {
        localStorage.removeItem("secureguard_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))

    const userRecord = demoUsers[email.toLowerCase()]
    if (userRecord && userRecord.password === password) {
      setUser(userRecord.user)
      localStorage.setItem("secureguard_user", JSON.stringify(userRecord.user))
      return true
    }
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("secureguard_user")
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
