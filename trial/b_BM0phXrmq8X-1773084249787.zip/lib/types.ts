export interface Employee {
  id: string
  name: string
  email: string
  phone: string
  role: string
  department: string
  status: "active" | "inactive" | "on-leave"
  joinDate: string
  salary: number
  avatar?: string
}

export interface AttendanceRecord {
  id: string
  employeeId: string
  employeeName: string
  date: string
  checkIn: string
  checkOut: string
  status: "present" | "absent" | "late" | "half-day"
  location: string
}

export interface SalaryRecord {
  id: string
  employeeId: string
  employeeName: string
  month: string
  baseSalary: number
  overtime: number
  deductions: number
  bonus: number
  netSalary: number
  status: "paid" | "pending" | "processing"
}

export interface Client {
  id: string
  name: string
  contactPerson: string
  email: string
  phone: string
  address: string
  contractStart: string
  contractEnd: string
  status: "active" | "inactive" | "pending"
  guardsAssigned: number
}

export interface DutyRoster {
  id: string
  employeeId: string
  employeeName: string
  clientId: string
  clientName: string
  date: string
  shift: "morning" | "afternoon" | "night"
  startTime: string
  endTime: string
  status: "scheduled" | "completed" | "cancelled"
}
