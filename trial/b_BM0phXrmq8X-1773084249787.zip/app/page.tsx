"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { StatCard } from "@/components/dashboard/stat-card"
import { AttendanceChart, RevenueChart } from "@/components/dashboard/overview-charts"
import { RecentActivity, TodayAttendance } from "@/components/dashboard/recent-activity"
import { dashboardStats, dutyRosters } from "@/lib/data"
import { sampleGeneratedDocuments } from "@/lib/document-types"
import { Users, Building2, Clock, DollarSign, CalendarDays, FileText } from "lucide-react"
import { Spinner } from "@/components/ui/spinner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const statusBadgeVariant: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  submitted: "secondary",
  approved: "default",
  rejected: "destructive",
}

export default function DashboardPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  const pendingDocs = sampleGeneratedDocuments.filter((d) => d.status === "submitted").length
  const todayDuties = dutyRosters.filter((d) => d.date === "2026-03-10").length

  return (
    <DashboardLayout
      title={`Welcome back, ${user.name.split(" ")[0]}!`}
      description="Here's an overview of your security operations and pending tasks."
    >
      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard
          title="Total Employees"
          value={dashboardStats.totalEmployees}
          change={`${dashboardStats.activeEmployees} active`}
          changeType="positive"
          icon={Users}
          iconColor="bg-blue-500/10 text-blue-600"
        />
        <StatCard
          title="Active Clients"
          value={dashboardStats.activeClients}
          change={`of ${dashboardStats.totalClients} total`}
          changeType="neutral"
          icon={Building2}
          iconColor="bg-emerald-500/10 text-emerald-600"
        />
        <StatCard
          title="Present Today"
          value={dashboardStats.todayAttendance}
          change="+2 from yesterday"
          changeType="positive"
          icon={Clock}
          iconColor="bg-violet-500/10 text-violet-600"
        />
        <StatCard
          title="Pending Salaries"
          value={dashboardStats.pendingSalaries}
          change="Processing..."
          changeType="neutral"
          icon={DollarSign}
          iconColor="bg-amber-500/10 text-amber-600"
        />
        <StatCard
          title="Today's Duties"
          value={todayDuties}
          change="Scheduled shifts"
          changeType="neutral"
          icon={CalendarDays}
          iconColor="bg-pink-500/10 text-pink-600"
        />
        <StatCard
          title="Pending Documents"
          value={pendingDocs}
          change="Awaiting approval"
          changeType={pendingDocs > 0 ? "negative" : "positive"}
          icon={FileText}
          iconColor="bg-teal-500/10 text-teal-600"
        />
      </div>

      {/* Quick Actions */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Frequently used document templates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Link href="/documents/create/resignation">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <span>Resignation Application</span>
              </Button>
            </Link>
            <Link href="/documents/create/leave-application">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <CalendarDays className="h-5 w-5 text-primary" />
                <span>Leave Application</span>
              </Button>
            </Link>
            <Link href="/documents/create/incident-report">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <span>Incident Report</span>
              </Button>
            </Link>
            <Link href="/documents/create/shift-handover">
              <Button variant="outline" className="w-full h-auto py-4 flex-col gap-2">
                <Clock className="h-5 w-5 text-primary" />
                <span>Shift Handover</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Recent Documents */}
      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Documents</CardTitle>
            <CardDescription>Latest documents requiring attention</CardDescription>
          </div>
          <Link href="/documents">
            <Button variant="outline" size="sm">View All</Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {sampleGeneratedDocuments.slice(0, 4).map((doc) => (
              <div
                key={doc.id}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                    <FileText className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-foreground">{doc.templateName}</p>
                    <p className="text-xs text-muted-foreground">
                      {doc.createdByName} - {new Date(doc.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Badge variant={statusBadgeVariant[doc.status]}>{doc.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Charts Row */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <AttendanceChart />
        <RevenueChart />
      </div>

      {/* Activity Row */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <RecentActivity />
        <TodayAttendance />
      </div>
    </DashboardLayout>
  )
}
