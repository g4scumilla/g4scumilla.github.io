"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { salaryRecords, employees } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Search, DollarSign, Plus, Download, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"

const statusConfig = {
  paid: { color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20", icon: CheckCircle },
  pending: { color: "bg-amber-500/10 text-amber-600 border-amber-500/20", icon: Clock },
  processing: { color: "bg-blue-500/10 text-blue-600 border-blue-500/20", icon: AlertCircle },
}

export default function SalaryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [filterMonth, setFilterMonth] = useState<string>("February 2026")

  const filteredRecords = salaryRecords.filter((record) => {
    const matchesSearch = record.employeeName.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = filterStatus === "all" || record.status === filterStatus
    const matchesMonth = record.month === filterMonth
    return matchesSearch && matchesFilter && matchesMonth
  })

  const totalPayroll = salaryRecords.reduce((sum, r) => sum + r.netSalary, 0)
  const paidAmount = salaryRecords.filter((r) => r.status === "paid").reduce((sum, r) => sum + r.netSalary, 0)
  const pendingAmount = salaryRecords.filter((r) => r.status === "pending").reduce((sum, r) => sum + r.netSalary, 0)

  return (
    <DashboardLayout
      title="Salary Records"
      description="Manage payroll and salary disbursements"
    >
      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Payroll</p>
              <p className="mt-2 text-3xl font-semibold text-foreground">
                ${totalPayroll.toLocaleString()}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">February 2026</p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <DollarSign className="h-6 w-6 text-primary" />
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Paid</p>
              <p className="mt-2 text-3xl font-semibold text-emerald-600">
                ${paidAmount.toLocaleString()}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {salaryRecords.filter((r) => r.status === "paid").length} employees
              </p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-500/10">
              <CheckCircle className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="mt-2 text-3xl font-semibold text-amber-600">
                ${pendingAmount.toLocaleString()}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {salaryRecords.filter((r) => r.status === "pending").length} employees
              </p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-amber-500/10">
              <Clock className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Record
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Add Salary Record</DialogTitle>
                <DialogDescription>
                  Create a new salary record for an employee
                </DialogDescription>
              </DialogHeader>
              <FieldGroup className="mt-4">
                <Field>
                  <FieldLabel>Employee</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select employee" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field>
                    <FieldLabel>Base Salary</FieldLabel>
                    <Input type="number" placeholder="3000" />
                  </Field>
                  <Field>
                    <FieldLabel>Overtime</FieldLabel>
                    <Input type="number" placeholder="0" />
                  </Field>
                  <Field>
                    <FieldLabel>Bonus</FieldLabel>
                    <Input type="number" placeholder="0" />
                  </Field>
                  <Field>
                    <FieldLabel>Deductions</FieldLabel>
                    <Input type="number" placeholder="0" />
                  </Field>
                </div>
                <Field>
                  <FieldLabel>Month</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select month" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="January 2026">January 2026</SelectItem>
                      <SelectItem value="February 2026">February 2026</SelectItem>
                      <SelectItem value="March 2026">March 2026</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Button className="w-full mt-2">Create Record</Button>
              </FieldGroup>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Table */}
      <div className="mt-6 rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Employee</TableHead>
              <TableHead className="font-semibold hidden sm:table-cell">Month</TableHead>
              <TableHead className="font-semibold hidden md:table-cell text-right">Base</TableHead>
              <TableHead className="font-semibold hidden lg:table-cell text-right">Overtime</TableHead>
              <TableHead className="font-semibold hidden lg:table-cell text-right">Bonus</TableHead>
              <TableHead className="font-semibold hidden md:table-cell text-right">Deductions</TableHead>
              <TableHead className="font-semibold text-right">Net Salary</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRecords.map((record) => {
              const StatusIcon = statusConfig[record.status].icon
              return (
                <TableRow key={record.id} className="hover:bg-muted/50">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
                        {record.employeeName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{record.employeeName}</p>
                        <p className="text-xs text-muted-foreground">{record.employeeId}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground">
                    {record.month}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-right">
                    ${record.baseSalary.toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-right text-emerald-600">
                    +${record.overtime.toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-right text-emerald-600">
                    +${record.bonus.toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-right text-red-500">
                    -${record.deductions.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    ${record.netSalary.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`capitalize ${statusConfig[record.status].color}`}
                    >
                      <StatusIcon className="mr-1 h-3 w-3" />
                      {record.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>
    </DashboardLayout>
  )
}
