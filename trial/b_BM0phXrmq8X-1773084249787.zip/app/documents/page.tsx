"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  FileText,
  AlertTriangle,
  GraduationCap,
  Calendar,
  FileWarning,
  ArrowRightLeft,
  Shirt,
  Star,
  Clock,
  Users,
  Plus,
  Eye,
  Printer,
  MoreHorizontal,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { documentTemplates, sampleGeneratedDocuments, type GeneratedDocument } from "@/lib/document-types"
import { Spinner } from "@/components/ui/spinner"
import { useEffect } from "react"

const iconMap: Record<string, React.ElementType> = {
  FileText,
  AlertTriangle,
  GraduationCap,
  Calendar,
  FileWarning,
  ArrowRightLeft,
  Shirt,
  Star,
  Clock,
  Users,
}

const categoryColors: Record<string, string> = {
  hr: "bg-blue-100 text-blue-700",
  operations: "bg-emerald-100 text-emerald-700",
  training: "bg-amber-100 text-amber-700",
  compliance: "bg-purple-100 text-purple-700",
}

const statusBadgeVariant: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  submitted: "secondary",
  approved: "default",
  rejected: "destructive",
}

export default function DocumentsPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const [documents, setDocuments] = useState<GeneratedDocument[]>(sampleGeneratedDocuments)
  const [activeTab, setActiveTab] = useState("templates")

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  const handleCreateDocument = (templateId: string) => {
    router.push(`/documents/create/${templateId}`)
  }

  const handleViewDocument = (docId: string) => {
    router.push(`/documents/view/${docId}`)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Document Automation</h1>
            <p className="text-muted-foreground">Generate and manage official documents</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="my-documents">My Documents</TabsTrigger>
          </TabsList>

          {/* Templates Tab */}
          <TabsContent value="templates" className="mt-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {documentTemplates.map((template) => {
                const Icon = iconMap[template.icon] || FileText
                return (
                  <Card
                    key={template.id}
                    className="group hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => handleCreateDocument(template.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <Badge variant="outline" className={categoryColors[template.category]}>
                          {template.category}
                        </Badge>
                      </div>
                      <CardTitle className="mt-3 text-base">{template.name}</CardTitle>
                      <CardDescription className="text-sm">
                        {template.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Create Document
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          {/* My Documents Tab */}
          <TabsContent value="my-documents" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Documents</CardTitle>
                <CardDescription>
                  Documents you have created or that require your attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Document</TableHead>
                        <TableHead className="hidden sm:table-cell">Created By</TableHead>
                        <TableHead className="hidden md:table-cell">Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-[80px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {documents.map((doc) => (
                        <TableRow key={doc.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium text-foreground">{doc.templateName}</p>
                              <p className="text-xs text-muted-foreground sm:hidden">
                                {doc.createdByName}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            {doc.createdByName}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {new Date(doc.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={statusBadgeVariant[doc.status]}>
                              {doc.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDocument(doc.id)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Printer className="mr-2 h-4 w-4" />
                                  Print
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
