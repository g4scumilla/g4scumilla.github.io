"use client"

import { useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Spinner } from "@/components/ui/spinner"
import { ArrowLeft, Printer, FileDown, CheckCircle, XCircle } from "lucide-react"
import { sampleGeneratedDocuments } from "@/lib/document-types"

const statusBadgeVariant: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  submitted: "secondary",
  approved: "default",
  rejected: "destructive",
}

export default function ViewDocumentPage() {
  const router = useRouter()
  const params = useParams()
  const { user, isLoading } = useAuth()

  const docId = params.docId as string
  const document = sampleGeneratedDocuments.find((d) => d.id === docId)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  if (!document) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-20">
          <p className="text-muted-foreground">Document not found</p>
          <Button variant="link" onClick={() => router.push("/documents")}>
            Back to Documents
          </Button>
        </div>
      </DashboardLayout>
    )
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.push("/documents")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{document.templateName}</h1>
              <p className="text-muted-foreground">Document ID: {document.id}</p>
            </div>
          </div>
          <div className="flex gap-2 ml-14 sm:ml-0">
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
            <Button variant="outline">
              <FileDown className="mr-2 h-4 w-4" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Document Preview */}
        <Card className="max-w-3xl print:shadow-none print:border-none">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <CardTitle>{document.templateName}</CardTitle>
              <Badge variant={statusBadgeVariant[document.status]}>{document.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {/* Company Header */}
            <div className="text-center mb-8 pb-6 border-b">
              <h2 className="text-xl font-bold text-foreground">SECUREGUARD SECURITY SERVICES</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Professional Security Solutions
              </p>
              <p className="text-xs text-muted-foreground">
                123 Security Plaza, Business District
              </p>
            </div>

            {/* Document Title */}
            <div className="text-center mb-8">
              <h3 className="text-lg font-semibold uppercase tracking-wide border-b-2 border-primary inline-block pb-1">
                {document.templateName}
              </h3>
            </div>

            {/* Document Info */}
            <div className="grid gap-4 mb-8">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Document ID:</span>
                  <span className="ml-2 font-medium">{document.id}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Date:</span>
                  <span className="ml-2 font-medium">
                    {new Date(document.createdAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground">Created By:</span>
                  <span className="ml-2 font-medium">{document.createdByName}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Employee ID:</span>
                  <span className="ml-2 font-medium">{document.createdBy}</span>
                </div>
              </div>
            </div>

            {/* Document Content */}
            <div className="space-y-4 mb-8">
              <h4 className="font-semibold text-foreground">Details:</h4>
              <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                {Object.entries(document.data).map(([key, value]) => (
                  <div key={key} className="flex flex-col sm:flex-row sm:gap-4">
                    <span className="text-sm text-muted-foreground capitalize min-w-[140px]">
                      {key.replace(/([A-Z])/g, " $1").trim()}:
                    </span>
                    <span className="text-sm font-medium text-foreground">
                      {typeof value === "boolean" ? (value ? "Yes" : "No") : String(value)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Signatures Section */}
            <div className="grid grid-cols-2 gap-8 pt-8 border-t mt-8">
              <div className="text-center">
                <div className="border-b border-dashed border-muted-foreground h-12 mb-2" />
                <p className="text-sm text-muted-foreground">Employee Signature</p>
                <p className="text-xs text-muted-foreground mt-1">{document.createdByName}</p>
              </div>
              <div className="text-center">
                <div className="border-b border-dashed border-muted-foreground h-12 mb-2" />
                <p className="text-sm text-muted-foreground">Authorized Signature</p>
                <p className="text-xs text-muted-foreground mt-1">Management</p>
              </div>
            </div>

            {/* Status Actions for Admin */}
            {user.role === "admin" && document.status === "submitted" && (
              <div className="flex justify-center gap-4 pt-8 mt-8 border-t print:hidden">
                <Button variant="outline" className="text-destructive hover:bg-destructive hover:text-destructive-foreground">
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject
                </Button>
                <Button className="bg-green-600 hover:bg-green-700">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approve
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
