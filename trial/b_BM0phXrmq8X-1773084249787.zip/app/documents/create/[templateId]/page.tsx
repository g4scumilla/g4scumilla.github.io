"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"
import { Spinner } from "@/components/ui/spinner"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ArrowLeft, Save, Send, Printer, FileDown } from "lucide-react"
import { documentTemplates } from "@/lib/document-types"
import { employees } from "@/lib/data"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { CheckCircle } from "lucide-react"

export default function CreateDocumentPage() {
  const router = useRouter()
  const params = useParams()
  const { user, isLoading } = useAuth()
  const [isSaving, setIsSaving] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [formData, setFormData] = useState<Record<string, string>>({})

  const templateId = params.templateId as string
  const template = documentTemplates.find((t) => t.id === templateId)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    )
  }

  if (!template) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-20">
          <p className="text-muted-foreground">Template not found</p>
          <Button variant="link" onClick={() => router.push("/documents")}>
            Back to Documents
          </Button>
        </div>
      </DashboardLayout>
    )
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (asDraft: boolean = false) => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSaving(false)
    setShowSuccess(true)
  }

  const handlePrint = () => {
    window.print()
  }

  const renderFormFields = () => {
    switch (templateId) {
      case "resignation":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Employee Name</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel>Employee ID</FieldLabel>
              <Input value={user.employeeId} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel>Department</FieldLabel>
              <Input value={user.department} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel htmlFor="lastWorkingDate">Proposed Last Working Date</FieldLabel>
              <Input
                id="lastWorkingDate"
                type="date"
                value={formData.lastWorkingDate || ""}
                onChange={(e) => handleInputChange("lastWorkingDate", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="noticePeriod">Notice Period</FieldLabel>
              <Select
                value={formData.noticePeriod || ""}
                onValueChange={(value) => handleInputChange("noticePeriod", value)}
              >
                <SelectTrigger id="noticePeriod">
                  <SelectValue placeholder="Select notice period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15 days">15 Days</SelectItem>
                  <SelectItem value="30 days">30 Days</SelectItem>
                  <SelectItem value="60 days">60 Days</SelectItem>
                  <SelectItem value="90 days">90 Days</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="reason">Reason for Resignation</FieldLabel>
              <Textarea
                id="reason"
                placeholder="Please provide your reason for resignation..."
                value={formData.reason || ""}
                onChange={(e) => handleInputChange("reason", e.target.value)}
                rows={4}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="remarks">Additional Remarks (Optional)</FieldLabel>
              <Textarea
                id="remarks"
                placeholder="Any additional information..."
                value={formData.remarks || ""}
                onChange={(e) => handleInputChange("remarks", e.target.value)}
                rows={3}
              />
            </Field>
          </FieldGroup>
        )

      case "caution-letter":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="employeeTo">Employee Name</FieldLabel>
              <Select
                value={formData.employeeTo || ""}
                onValueChange={(value) => handleInputChange("employeeTo", value)}
              >
                <SelectTrigger id="employeeTo">
                  <SelectValue placeholder="Select employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.name}>
                      {emp.name} - {emp.role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="incidentDate">Incident Date</FieldLabel>
              <Input
                id="incidentDate"
                type="date"
                value={formData.incidentDate || ""}
                onChange={(e) => handleInputChange("incidentDate", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="violationType">Type of Violation</FieldLabel>
              <Select
                value={formData.violationType || ""}
                onValueChange={(value) => handleInputChange("violationType", value)}
              >
                <SelectTrigger id="violationType">
                  <SelectValue placeholder="Select violation type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="attendance">Attendance Issues</SelectItem>
                  <SelectItem value="conduct">Misconduct</SelectItem>
                  <SelectItem value="performance">Poor Performance</SelectItem>
                  <SelectItem value="policy">Policy Violation</SelectItem>
                  <SelectItem value="safety">Safety Violation</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="description">Description of Incident</FieldLabel>
              <Textarea
                id="description"
                placeholder="Provide detailed description of the incident..."
                value={formData.description || ""}
                onChange={(e) => handleInputChange("description", e.target.value)}
                rows={4}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="previousWarnings">Previous Warnings (if any)</FieldLabel>
              <Select
                value={formData.previousWarnings || ""}
                onValueChange={(value) => handleInputChange("previousWarnings", value)}
              >
                <SelectTrigger id="previousWarnings">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">No previous warnings</SelectItem>
                  <SelectItem value="1">1 Previous Warning</SelectItem>
                  <SelectItem value="2">2 Previous Warnings</SelectItem>
                  <SelectItem value="3+">3 or more Warnings</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="actionRequired">Action Required from Employee</FieldLabel>
              <Textarea
                id="actionRequired"
                placeholder="Specify the corrective actions expected..."
                value={formData.actionRequired || ""}
                onChange={(e) => handleInputChange("actionRequired", e.target.value)}
                rows={3}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="consequenceNotice">Consequence of Non-Compliance</FieldLabel>
              <Textarea
                id="consequenceNotice"
                placeholder="Specify consequences if behavior continues..."
                value={formData.consequenceNotice || ""}
                onChange={(e) => handleInputChange("consequenceNotice", e.target.value)}
                rows={2}
              />
            </Field>
          </FieldGroup>
        )

      case "training-sheet":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="traineeName">Trainee Name</FieldLabel>
              <Select
                value={formData.traineeName || ""}
                onValueChange={(value) => handleInputChange("traineeName", value)}
              >
                <SelectTrigger id="traineeName">
                  <SelectValue placeholder="Select trainee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.name}>
                      {emp.name} - {emp.role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="trainingType">Training Type</FieldLabel>
              <Select
                value={formData.trainingType || ""}
                onValueChange={(value) => handleInputChange("trainingType", value)}
              >
                <SelectTrigger id="trainingType">
                  <SelectValue placeholder="Select training type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Fire Safety Protocol">Fire Safety Protocol</SelectItem>
                  <SelectItem value="First Aid Training">First Aid Training</SelectItem>
                  <SelectItem value="Security Procedures">Security Procedures</SelectItem>
                  <SelectItem value="Emergency Response">Emergency Response</SelectItem>
                  <SelectItem value="Customer Service">Customer Service</SelectItem>
                  <SelectItem value="Equipment Handling">Equipment Handling</SelectItem>
                  <SelectItem value="Access Control Systems">Access Control Systems</SelectItem>
                  <SelectItem value="CCTV Monitoring">CCTV Monitoring</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="trainingDate">Training Date</FieldLabel>
              <Input
                id="trainingDate"
                type="date"
                value={formData.trainingDate || ""}
                onChange={(e) => handleInputChange("trainingDate", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="duration">Duration (hours)</FieldLabel>
              <Input
                id="duration"
                type="number"
                min="1"
                max="40"
                placeholder="Enter training duration"
                value={formData.duration || ""}
                onChange={(e) => handleInputChange("duration", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="trainer">Trainer Name</FieldLabel>
              <Input
                id="trainer"
                placeholder="Enter trainer name"
                value={formData.trainer || ""}
                onChange={(e) => handleInputChange("trainer", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="score">Assessment Score (%)</FieldLabel>
              <Input
                id="score"
                type="number"
                min="0"
                max="100"
                placeholder="Enter assessment score"
                value={formData.score || ""}
                onChange={(e) => handleInputChange("score", e.target.value)}
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="result">Training Result</FieldLabel>
              <Select
                value={formData.result || ""}
                onValueChange={(value) => handleInputChange("result", value)}
              >
                <SelectTrigger id="result">
                  <SelectValue placeholder="Select result" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="passed">Passed</SelectItem>
                  <SelectItem value="failed">Failed - Needs Retraining</SelectItem>
                  <SelectItem value="pending">Pending Assessment</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="remarks">Trainer Remarks</FieldLabel>
              <Textarea
                id="remarks"
                placeholder="Additional comments about the training..."
                value={formData.remarks || ""}
                onChange={(e) => handleInputChange("remarks", e.target.value)}
                rows={3}
              />
            </Field>
          </FieldGroup>
        )

      case "leave-application":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Employee Name</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel>Employee ID</FieldLabel>
              <Input value={user.employeeId} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel htmlFor="leaveType">Leave Type</FieldLabel>
              <Select
                value={formData.leaveType || ""}
                onValueChange={(value) => handleInputChange("leaveType", value)}
              >
                <SelectTrigger id="leaveType">
                  <SelectValue placeholder="Select leave type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual Leave</SelectItem>
                  <SelectItem value="sick">Sick Leave</SelectItem>
                  <SelectItem value="emergency">Emergency Leave</SelectItem>
                  <SelectItem value="unpaid">Unpaid Leave</SelectItem>
                  <SelectItem value="maternity">Maternity Leave</SelectItem>
                  <SelectItem value="paternity">Paternity Leave</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field>
                <FieldLabel htmlFor="startDate">Start Date</FieldLabel>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate || ""}
                  onChange={(e) => handleInputChange("startDate", e.target.value)}
                  required
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="endDate">End Date</FieldLabel>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate || ""}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                  required
                />
              </Field>
            </div>
            <Field>
              <FieldLabel htmlFor="reason">Reason for Leave</FieldLabel>
              <Textarea
                id="reason"
                placeholder="Provide reason for leave request..."
                value={formData.reason || ""}
                onChange={(e) => handleInputChange("reason", e.target.value)}
                rows={3}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="contactNumber">Emergency Contact Number</FieldLabel>
              <Input
                id="contactNumber"
                type="tel"
                placeholder="Enter contact number during leave"
                value={formData.contactNumber || ""}
                onChange={(e) => handleInputChange("contactNumber", e.target.value)}
              />
            </Field>
          </FieldGroup>
        )

      case "incident-report":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Reported By</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field>
                <FieldLabel htmlFor="incidentDate">Incident Date</FieldLabel>
                <Input
                  id="incidentDate"
                  type="date"
                  value={formData.incidentDate || ""}
                  onChange={(e) => handleInputChange("incidentDate", e.target.value)}
                  required
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="incidentTime">Incident Time</FieldLabel>
                <Input
                  id="incidentTime"
                  type="time"
                  value={formData.incidentTime || ""}
                  onChange={(e) => handleInputChange("incidentTime", e.target.value)}
                  required
                />
              </Field>
            </div>
            <Field>
              <FieldLabel htmlFor="location">Location</FieldLabel>
              <Input
                id="location"
                placeholder="Enter incident location"
                value={formData.location || ""}
                onChange={(e) => handleInputChange("location", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="incidentType">Incident Type</FieldLabel>
              <Select
                value={formData.incidentType || ""}
                onValueChange={(value) => handleInputChange("incidentType", value)}
              >
                <SelectTrigger id="incidentType">
                  <SelectValue placeholder="Select incident type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unauthorized-access">Unauthorized Access Attempt</SelectItem>
                  <SelectItem value="theft">Theft / Attempted Theft</SelectItem>
                  <SelectItem value="vandalism">Vandalism</SelectItem>
                  <SelectItem value="altercation">Physical Altercation</SelectItem>
                  <SelectItem value="medical">Medical Emergency</SelectItem>
                  <SelectItem value="fire">Fire / Fire Alarm</SelectItem>
                  <SelectItem value="suspicious">Suspicious Activity</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field>
              <FieldLabel htmlFor="description">Incident Description</FieldLabel>
              <Textarea
                id="description"
                placeholder="Provide detailed description of what happened..."
                value={formData.description || ""}
                onChange={(e) => handleInputChange("description", e.target.value)}
                rows={4}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="actionTaken">Immediate Action Taken</FieldLabel>
              <Textarea
                id="actionTaken"
                placeholder="What actions were taken in response..."
                value={formData.actionTaken || ""}
                onChange={(e) => handleInputChange("actionTaken", e.target.value)}
                rows={3}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="witnesses">Witnesses (if any)</FieldLabel>
              <Input
                id="witnesses"
                placeholder="Names of witnesses"
                value={formData.witnesses || ""}
                onChange={(e) => handleInputChange("witnesses", e.target.value)}
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="policeCalled">Police Notified?</FieldLabel>
              <Select
                value={formData.policeCalled || ""}
                onValueChange={(value) => handleInputChange("policeCalled", value)}
              >
                <SelectTrigger id="policeCalled">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                  <SelectItem value="na">Not Applicable</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </FieldGroup>
        )

      case "shift-handover":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Outgoing Officer</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel htmlFor="incomingOfficer">Incoming Officer</FieldLabel>
              <Select
                value={formData.incomingOfficer || ""}
                onValueChange={(value) => handleInputChange("incomingOfficer", value)}
              >
                <SelectTrigger id="incomingOfficer">
                  <SelectValue placeholder="Select incoming officer" />
                </SelectTrigger>
                <SelectContent>
                  {employees
                    .filter((emp) => emp.role.includes("Guard") || emp.role.includes("Supervisor"))
                    .map((emp) => (
                      <SelectItem key={emp.id} value={emp.name}>
                        {emp.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field>
                <FieldLabel htmlFor="handoverDate">Date</FieldLabel>
                <Input
                  id="handoverDate"
                  type="date"
                  value={formData.handoverDate || ""}
                  onChange={(e) => handleInputChange("handoverDate", e.target.value)}
                  required
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="handoverTime">Time</FieldLabel>
                <Input
                  id="handoverTime"
                  type="time"
                  value={formData.handoverTime || ""}
                  onChange={(e) => handleInputChange("handoverTime", e.target.value)}
                  required
                />
              </Field>
            </div>
            <Field>
              <FieldLabel htmlFor="location">Post / Location</FieldLabel>
              <Input
                id="location"
                placeholder="Enter post location"
                value={formData.location || ""}
                onChange={(e) => handleInputChange("location", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="shiftSummary">Shift Summary</FieldLabel>
              <Textarea
                id="shiftSummary"
                placeholder="Summary of events during your shift..."
                value={formData.shiftSummary || ""}
                onChange={(e) => handleInputChange("shiftSummary", e.target.value)}
                rows={3}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="pendingTasks">Pending Tasks</FieldLabel>
              <Textarea
                id="pendingTasks"
                placeholder="Tasks that need attention by incoming officer..."
                value={formData.pendingTasks || ""}
                onChange={(e) => handleInputChange("pendingTasks", e.target.value)}
                rows={2}
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="equipmentStatus">Equipment Status</FieldLabel>
              <Textarea
                id="equipmentStatus"
                placeholder="Status of equipment (radio, flashlight, keys, etc.)..."
                value={formData.equipmentStatus || ""}
                onChange={(e) => handleInputChange("equipmentStatus", e.target.value)}
                rows={2}
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="specialInstructions">Special Instructions</FieldLabel>
              <Textarea
                id="specialInstructions"
                placeholder="Any special instructions for the incoming officer..."
                value={formData.specialInstructions || ""}
                onChange={(e) => handleInputChange("specialInstructions", e.target.value)}
                rows={2}
              />
            </Field>
          </FieldGroup>
        )

      case "overtime-request":
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Employee Name</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel>Employee ID</FieldLabel>
              <Input value={user.employeeId} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel htmlFor="overtimeDate">Overtime Date</FieldLabel>
              <Input
                id="overtimeDate"
                type="date"
                value={formData.overtimeDate || ""}
                onChange={(e) => handleInputChange("overtimeDate", e.target.value)}
                required
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field>
                <FieldLabel htmlFor="startTime">Start Time</FieldLabel>
                <Input
                  id="startTime"
                  type="time"
                  value={formData.startTime || ""}
                  onChange={(e) => handleInputChange("startTime", e.target.value)}
                  required
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="endTime">End Time</FieldLabel>
                <Input
                  id="endTime"
                  type="time"
                  value={formData.endTime || ""}
                  onChange={(e) => handleInputChange("endTime", e.target.value)}
                  required
                />
              </Field>
            </div>
            <Field>
              <FieldLabel htmlFor="totalHours">Total Hours</FieldLabel>
              <Input
                id="totalHours"
                type="number"
                min="1"
                max="12"
                placeholder="Enter total overtime hours"
                value={formData.totalHours || ""}
                onChange={(e) => handleInputChange("totalHours", e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="reason">Reason for Overtime</FieldLabel>
              <Textarea
                id="reason"
                placeholder="Explain why overtime is needed..."
                value={formData.reason || ""}
                onChange={(e) => handleInputChange("reason", e.target.value)}
                rows={3}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="clientSite">Client Site (if applicable)</FieldLabel>
              <Input
                id="clientSite"
                placeholder="Enter client site name"
                value={formData.clientSite || ""}
                onChange={(e) => handleInputChange("clientSite", e.target.value)}
              />
            </Field>
          </FieldGroup>
        )

      default:
        return (
          <FieldGroup>
            <Field>
              <FieldLabel>Employee Name</FieldLabel>
              <Input value={user.name} disabled className="bg-muted" />
            </Field>
            <Field>
              <FieldLabel htmlFor="details">Details</FieldLabel>
              <Textarea
                id="details"
                placeholder="Enter document details..."
                value={formData.details || ""}
                onChange={(e) => handleInputChange("details", e.target.value)}
                rows={6}
                required
              />
            </Field>
          </FieldGroup>
        )
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/documents")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{template.name}</h1>
            <p className="text-muted-foreground">{template.description}</p>
          </div>
        </div>

        {/* Form */}
        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle>Document Details</CardTitle>
            <CardDescription>
              Fill in all required fields to generate the document
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderFormFields()}

            <div className="flex flex-col gap-3 mt-6 pt-6 border-t sm:flex-row sm:justify-between">
              <div className="flex gap-2">
                <Button variant="outline" onClick={handlePrint}>
                  <Printer className="mr-2 h-4 w-4" />
                  Print Preview
                </Button>
                <Button variant="outline">
                  <FileDown className="mr-2 h-4 w-4" />
                  Export PDF
                </Button>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  onClick={() => handleSubmit(true)}
                  disabled={isSaving}
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Draft
                </Button>
                <Button onClick={() => handleSubmit(false)} disabled={isSaving}>
                  {isSaving ? <Spinner className="mr-2 h-4 w-4" /> : <Send className="mr-2 h-4 w-4" />}
                  Submit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent>
          <DialogHeader>
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100 mb-4">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <DialogTitle className="text-center">Document Submitted</DialogTitle>
            <DialogDescription className="text-center">
              Your {template.name.toLowerCase()} has been submitted successfully and is pending approval.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-center">
            <Button onClick={() => router.push("/documents")}>
              Back to Documents
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
