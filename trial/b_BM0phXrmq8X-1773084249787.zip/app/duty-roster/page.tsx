"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { dutyRosters, employees, clients } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Search,
  Plus,
  Calendar,
  Clock,
  MapPin,
  Sun,
  Sunset,
  Moon,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"

const shiftConfig = {
  morning: { icon: Sun, color: "bg-amber-500/10 text-amber-600 border-amber-500/20", label: "Morning" },
  afternoon: { icon: Sunset, color: "bg-orange-500/10 text-orange-600 border-orange-500/20", label: "Afternoon" },
  night: { icon: Moon, color: "bg-indigo-500/10 text-indigo-600 border-indigo-500/20", label: "Night" },
}

const statusConfig = {
  scheduled: { color: "bg-blue-500/10 text-blue-600 border-blue-500/20" },
  completed: { color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
  cancelled: { color: "bg-red-500/10 text-red-600 border-red-500/20" },
}

export default function DutyRosterPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterShift, setFilterShift] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")

  const filteredRosters = dutyRosters.filter((roster) => {
    const matchesSearch =
      roster.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      roster.clientName.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesShift = filterShift === "all" || roster.shift === filterShift
    const matchesStatus = filterStatus === "all" || roster.status === filterStatus
    return matchesSearch && matchesShift && matchesStatus
  })

  const stats = {
    scheduled: dutyRosters.filter((r) => r.status === "scheduled").length,
    completed: dutyRosters.filter((r) => r.status === "completed").length,
    morning: dutyRosters.filter((r) => r.shift === "morning").length,
    night: dutyRosters.filter((r) => r.shift === "night").length,
  }

  return (
    <DashboardLayout
      title="Duty Roster"
      description="Schedule and manage guard assignments"
    >
      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-500/10">
            <Calendar className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Scheduled</p>
            <p className="text-2xl font-semibold text-foreground">{stats.scheduled}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-emerald-500/10">
            <CheckCircle className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Completed</p>
            <p className="text-2xl font-semibold text-foreground">{stats.completed}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-amber-500/10">
            <Sun className="h-5 w-5 text-amber-600" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Morning Shifts</p>
            <p className="text-2xl font-semibold text-foreground">{stats.morning}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-indigo-500/10">
            <Moon className="h-5 w-5 text-indigo-600" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Night Shifts</p>
            <p className="text-2xl font-semibold text-foreground">{stats.night}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-wrap items-center gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search duties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={filterShift} onValueChange={setFilterShift}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Shift" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Shifts</SelectItem>
              <SelectItem value="morning">Morning</SelectItem>
              <SelectItem value="afternoon">Afternoon</SelectItem>
              <SelectItem value="night">Night</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Duty
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Schedule New Duty</DialogTitle>
              <DialogDescription>
                Assign a guard to a client location
              </DialogDescription>
            </DialogHeader>
            <FieldGroup className="mt-4">
              <Field>
                <FieldLabel>Employee</FieldLabel>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees
                      .filter((e) => e.status === "active")
                      .map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field>
                <FieldLabel>Client</FieldLabel>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients
                      .filter((c) => c.status === "active")
                      .map((client) => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field>
                <FieldLabel>Date</FieldLabel>
                <Input type="date" />
              </Field>
              <Field>
                <FieldLabel>Shift</FieldLabel>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select shift" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (06:00 - 14:00)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (14:00 - 22:00)</SelectItem>
                    <SelectItem value="night">Night (22:00 - 06:00)</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Button className="w-full mt-2">Schedule Duty</Button>
            </FieldGroup>
          </DialogContent>
        </Dialog>
      </div>

      {/* Table */}
      <div className="mt-6 rounded-xl border border-border bg-card shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Employee</TableHead>
              <TableHead className="font-semibold hidden sm:table-cell">Client</TableHead>
              <TableHead className="font-semibold">Date</TableHead>
              <TableHead className="font-semibold hidden md:table-cell">Shift</TableHead>
              <TableHead className="font-semibold hidden lg:table-cell">Time</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRosters.map((roster) => {
              const ShiftIcon = shiftConfig[roster.shift].icon
              return (
                <TableRow key={roster.id} className="hover:bg-muted/50">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
                        {roster.employeeName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{roster.employeeName}</p>
                        <p className="text-xs text-muted-foreground sm:hidden">
                          {roster.clientName}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate max-w-[200px]">{roster.clientName}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      {new Date(roster.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      })}
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <Badge variant="outline" className={`${shiftConfig[roster.shift].color}`}>
                      <ShiftIcon className="mr-1 h-3 w-3" />
                      {shiftConfig[roster.shift].label}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {roster.startTime} - {roster.endTime}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`capitalize ${statusConfig[roster.status].color}`}
                    >
                      {roster.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>
    </DashboardLayout>
  )
}
