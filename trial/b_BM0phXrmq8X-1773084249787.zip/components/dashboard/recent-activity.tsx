import { dutyRosters, attendanceRecords } from "@/lib/data"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, User } from "lucide-react"

export function RecentActivity() {
  const recentDuties = dutyRosters.slice(0, 5)

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <h3 className="text-base font-semibold text-card-foreground">Upcoming Duties</h3>
      <p className="text-sm text-muted-foreground">Scheduled shifts for today and tomorrow</p>
      <div className="mt-6 space-y-4">
        {recentDuties.map((duty) => (
          <div
            key={duty.id}
            className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-muted/50"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <User className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-card-foreground truncate">{duty.employeeName}</p>
              <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  <span className="truncate">{duty.clientName}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  {duty.startTime} - {duty.endTime}
                </span>
              </div>
            </div>
            <Badge
              variant={
                duty.status === "completed"
                  ? "default"
                  : duty.status === "scheduled"
                  ? "secondary"
                  : "destructive"
              }
              className="capitalize"
            >
              {duty.status}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  )
}

export function TodayAttendance() {
  const todayRecords = attendanceRecords.slice(0, 5)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "present":
        return "bg-emerald-500/10 text-emerald-600"
      case "late":
        return "bg-amber-500/10 text-amber-600"
      case "absent":
        return "bg-red-500/10 text-red-600"
      case "half-day":
        return "bg-blue-500/10 text-blue-600"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <h3 className="text-base font-semibold text-card-foreground">Today{"'"}s Attendance</h3>
      <p className="text-sm text-muted-foreground">Real-time attendance tracking</p>
      <div className="mt-6 space-y-3">
        {todayRecords.map((record) => (
          <div
            key={record.id}
            className="flex items-center justify-between rounded-lg border border-border p-3"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-medium text-secondary-foreground">
                {record.employeeName
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </div>
              <div>
                <p className="text-sm font-medium text-card-foreground">{record.employeeName}</p>
                <p className="text-xs text-muted-foreground">
                  {record.checkIn !== "-" ? `${record.checkIn} - ${record.checkOut}` : "Not checked in"}
                </p>
              </div>
            </div>
            <span
              className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${getStatusColor(
                record.status
              )}`}
            >
              {record.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
